module github.com/ECO-evidence-casework-one/eco/labs/presentation_bakeoff/fyne

go 1.23.0

require (
	fyne.io/fyne/v2 v2.8.0
	github.com/ECO-evidence-casework-one/eco v0.0.0
)

replace github.com/ECO-evidence-casework-one/eco => ../../..
