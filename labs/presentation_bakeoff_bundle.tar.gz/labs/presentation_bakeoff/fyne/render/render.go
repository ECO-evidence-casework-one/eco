package render

import (
	"fmt"
	"image"
	"image/color"
	"strings"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/driver/software"
	"fyne.io/fyne/v2/test"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"

	"github.com/ECO-evidence-casework-one/eco/labs/presentation_bakeoff/shared"
)

var (
	bg        = color.NRGBA{R: 246, G: 249, B: 248, A: 255}
	panel     = color.NRGBA{R: 255, G: 255, B: 255, A: 255}
	ink       = color.NRGBA{R: 9, G: 48, B: 55, A: 255}
	muted     = color.NRGBA{R: 86, G: 110, B: 114, A: 255}
	nav       = color.NRGBA{R: 0, G: 77, B: 78, A: 255}
	teal      = color.NRGBA{R: 0, G: 133, B: 124, A: 255}
	tealSoft  = color.NRGBA{R: 231, G: 247, B: 244, A: 255}
	blueSoft  = color.NRGBA{R: 235, G: 244, B: 255, A: 255}
	amberSoft = color.NRGBA{R: 255, G: 246, B: 229, A: 255}
	greenSoft = color.NRGBA{R: 234, G: 247, B: 237, A: 255}
)

type ecoTheme struct{ base fyne.Theme }

func newTheme() fyne.Theme { return ecoTheme{base: theme.LightTheme()} }
func (t ecoTheme) Color(n fyne.ThemeColorName, v fyne.ThemeVariant) color.Color {
	switch n {
	case theme.ColorNameBackground:
		return bg
	case theme.ColorNameForeground:
		return ink
	case theme.ColorNamePrimary:
		return teal
	case theme.ColorNameButton:
		return panel
	case theme.ColorNameHover:
		return tealSoft
	case theme.ColorNameInputBackground:
		return panel
	case theme.ColorNameSeparator:
		return color.NRGBA{R: 214, G: 226, B: 224, A: 255}
	case theme.ColorNameDisabled:
		return color.NRGBA{R: 145, G: 158, B: 160, A: 255}
	}
	return t.base.Color(n, v)
}
func (t ecoTheme) Font(s fyne.TextStyle) fyne.Resource     { return t.base.Font(s) }
func (t ecoTheme) Icon(n fyne.ThemeIconName) fyne.Resource { return t.base.Icon(n) }
func (t ecoTheme) Size(n fyne.ThemeSizeName) float32 {
	switch n {
	case theme.SizeNameText:
		return 14
	case theme.SizeNamePadding:
		return 6
	case theme.SizeNameInputBorder:
		return 1
	}
	return t.base.Size(n)
}

func Render(snapshot shared.Snapshot, screen string, width, height int) (image.Image, error) {
	test.NewApp()
	root := shell(snapshot, screen)
	c := software.NewCanvas()
	c.SetPadded(false)
	c.SetContent(root)
	c.Resize(fyne.NewSize(float32(width), float32(height)))
	return software.RenderCanvas(c, newTheme()), nil
}

func shell(s shared.Snapshot, screen string) fyne.CanvasObject {
	left := sidebar(s.Navigation, screen)
	top := topbar(s)
	bottom := statusbar()
	var center fyne.CanvasObject
	if screen == "ask-eco" {
		center = askECO(s.AskECO)
	} else {
		center = workspace(s.Workspace)
	}
	return container.NewBorder(top, bottom, left, nil, center)
}

func sidebar(items []shared.NavItem, active string) fyne.CanvasObject {
	bgRect := canvas.NewRectangle(nav)
	brand := container.NewVBox(text("ECO", 26, true, color.White), text("Evidence & Casework One", 13, true, color.White), text("Private · Offline", 11, false, color.NRGBA{R: 185, G: 224, B: 221, A: 255}), spacerH(14), text("MATTER", 10, true, color.NRGBA{R: 150, G: 204, B: 200, A: 255}))
	navBox := container.NewVBox()
	for _, it := range items {
		selected := (active == "workspace" && it.ID == "workspace") || (active == "ask-eco" && it.ID == "ask-eco")
		label := navGlyph(it.ID) + "  " + it.Label
		if it.Count > 0 {
			label += fmt.Sprintf("    %d", it.Count)
		}
		line := text(label, 12, selected, color.White)
		if selected {
			navBox.Add(surface(teal, container.NewPadded(line)))
		} else {
			navBox.Add(container.NewPadded(line))
		}
	}
	status := surface(color.NRGBA{R: 3, G: 96, B: 94, A: 255}, container.NewPadded(container.NewVBox(text("Casework Core ready", 11, true, color.White), text("4 evidence · 7 findings", 9, false, color.NRGBA{R: 198, G: 231, B: 228, A: 255}), text("Development Sentinel active", 9, false, color.NRGBA{R: 198, G: 231, B: 228, A: 255}))))
	content := container.NewBorder(brand, status, nil, nil, navBox)
	fixed := container.NewGridWrap(fyne.NewSize(190, 1), canvas.NewRectangle(color.Transparent))
	return container.NewStack(bgRect, fixed, container.NewPadded(content))
}

func navGlyph(id string) string {
	switch id {
	case "workspace":
		return "⌂"
	case "evidence":
		return "▤"
	case "findings":
		return "✓"
	case "timeline":
		return "◷"
	case "people":
		return "◎"
	case "issues":
		return "◇"
	case "work":
		return "☑"
	case "current-position":
		return "▥"
	case "reports":
		return "▧"
	case "ask-eco":
		return "◉"
	case "activity":
		return "↻"
	case "tools":
		return "•••"
	default:
		return "⚙"
	}
}

func topbar(s shared.Snapshot) fyne.CanvasObject {
	matter := secondaryButton("General Casework 1 ▾")
	search := widget.NewEntry()
	search.SetPlaceHolder("⌕  Search this Matter or run an action…     Ctrl+K")
	findings := secondaryButton(fmt.Sprintf("%d findings", s.Navigation[2].Count))
	ask := widget.NewButton("Ask ECO", func() {})
	ask.Importance = widget.HighImportance
	row := container.NewBorder(nil, nil, matter, container.NewHBox(findings, ask), search)
	return surface(panel, container.NewPadded(row))
}

func workspace(m shared.WorkspaceModel) fyne.CanvasObject {
	header := container.NewBorder(
		nil, nil,
		container.NewVBox(
			text("Matter Workspace", 24, true, ink),
			text("At-a-glance overview with key actions and updates.", 12, false, muted),
		),
		container.NewHBox(secondaryButton("What's new"), secondaryButton("Explain")),
		nil,
	)
	matterHeader := card(container.NewBorder(
		nil, nil,
		container.NewVBox(
			text(m.Title, 18, true, ink),
			text(m.Subtitle+" · "+m.Context, 10, false, muted),
		),
		secondaryButton("Edit Matter"),
		nil,
	))

	metricObjs := make([]fyne.CanvasObject, 0, len(m.Metrics))
	for _, mm := range m.Metrics {
		col := blueSoft
		switch mm.Tone {
		case "review":
			col = color.NRGBA{R: 244, G: 238, B: 255, A: 255}
		case "warning":
			col = amberSoft
		case "success":
			col = greenSoft
		}
		metricObjs = append(metricObjs, surface(col, container.NewPadded(container.NewVBox(
			text(mm.Value, 25, true, ink),
			text(mm.Label, 11, true, ink),
			text(mm.Detail, 9, false, muted),
		))))
	}
	metrics := container.NewGridWithColumns(4, metricObjs...)

	journeySteps := make([]fyne.CanvasObject, 0, len(m.Journey))
	for _, st := range m.Journey {
		journeySteps = append(journeySteps, container.NewVBox(
			text(fmt.Sprintf("%d  %s", st.Number, st.Label), 10, true, ink),
			text(st.Detail, 9, false, muted),
		))
	}
	journey := card(container.NewVBox(
		text("Case journey", 12, true, ink),
		container.NewGridWithColumns(5, journeySteps...),
	))

	threads := container.NewVBox(text("Key case threads", 12, true, ink))
	for i, th := range m.Threads {
		if i >= 3 {
			break
		}
		thread := container.NewVBox(
			container.NewBorder(nil, nil, text(th.Title, 11, true, ink), statusChip(th.Status), nil),
			text(fmt.Sprintf("%d sources · %d issue · %d missing · %d task · %d comm", th.EvidenceCount, th.IssueCount, th.MissingCount, th.TaskCount, th.CommunicationCount), 9, false, muted),
			wrapped(th.EvidenceExcerpt, 9, muted),
		)
		threads.Add(surface(bg, container.NewPadded(thread)))
	}
	threadCard := card(threads)

	found := container.NewVBox(text("What ECO found", 12, true, ink))
	for _, v := range m.FindingsSummary {
		found.Add(wrapped("•  "+v, 9, muted))
	}
	next := surface(tealSoft, container.NewPadded(container.NewVBox(
		text("Recommended next action", 11, true, ink),
		wrapped(m.NextActionTitle, 10, ink),
		wrapped(m.NextActionDetail, 9, muted),
		primaryButton("Open case thread"),
	)))
	right := container.NewVBox(card(found), next)
	body := container.NewHSplit(threadCard, right)
	body.Offset = .66

	quick := container.NewGridWithColumns(len(m.QuickActions))
	for _, a := range m.QuickActions {
		quick.Add(secondaryButton(a.Label))
	}
	content := container.NewVBox(header, matterHeader, metrics, journey, body, quick)
	return container.NewPadded(container.NewVScroll(content))
}

func askECO(m shared.AskECOModel) fyne.CanvasObject {
	header := container.NewBorder(
		nil, nil,
		container.NewVBox(
			text("Ask ECO", 24, true, ink),
			text("Private local casework conversation. Answers stay linked to this Matter and its sources.", 12, false, muted),
		),
		container.NewHBox(secondaryButton("New conversation"), secondaryButton("Export conversation")),
		nil,
	)

	convos := container.NewVBox(text("Conversations", 12, true, ink))
	for _, c := range m.Conversations {
		col := bg
		if c.Active {
			col = tealSoft
		}
		convos.Add(surface(col, container.NewPadded(container.NewVBox(
			text(c.Title, 10, true, ink),
			text(c.Updated, 9, false, muted),
		))))
	}
	left := card(convos)

	msgBox := container.NewVBox(
		container.NewBorder(nil, nil, text(m.MatterTitle, 11, true, ink), statusChip(m.StatusBadge), nil),
		text(m.ScopeSummary, 9, false, muted),
	)
	for _, msg := range m.Messages {
		col := panel
		who := "ECO"
		if msg.Role == "user" {
			col = tealSoft
			who = "You"
		}
		parts := container.NewVBox(
			text(who+"   "+msg.At, 9, true, muted),
			wrapped(msg.Text, 11, ink),
		)
		if len(msg.Sources) > 0 {
			names := make([]string, 0, len(msg.Sources))
			for _, src := range msg.Sources {
				names = append(names, src.Label)
			}
			parts.Add(wrapped("Sources: "+strings.Join(names, " · "), 9, teal))
		}
		msgBox.Add(surface(col, container.NewPadded(parts)))
	}

	entry := widget.NewMultiLineEntry()
	entry.SetPlaceHolder(m.ComposerPlaceholder)
	composer := container.NewBorder(
		nil, nil, nil, primaryButton("Send"),
		container.NewGridWrap(fyne.NewSize(100, 58), entry),
	)
	middle := card(container.NewBorder(nil, composer, nil, nil, container.NewVScroll(msgBox)))

	actions := container.NewVBox(text("Actions & questions", 12, true, ink))
	for _, a := range m.SuggestedQuestions {
		actions.Add(secondaryButton(a.Label))
	}
	actions.Add(text("Sources in this answer", 10, true, ink))
	for _, src := range m.Sources {
		actions.Add(wrapped("• "+src.Label, 9, teal))
	}
	right := card(container.NewVScroll(actions))

	leftWrap := container.NewGridWrap(fyne.NewSize(220, 500), left)
	rightWrap := container.NewGridWrap(fyne.NewSize(240, 500), right)
	body := container.NewBorder(nil, nil, leftWrap, rightWrap, middle)
	return container.NewPadded(container.NewBorder(header, nil, nil, nil, body))
}

func statusbar() fyne.CanvasObject {
	return surface(panel, container.NewPadded(container.NewBorder(nil, nil, text("●  Ready", 9, true, teal), text("Auto-save: On   ·   Local only   ·   Sentinel: Active", 9, false, muted), nil)))
}
func card(content fyne.CanvasObject) fyne.CanvasObject { return widget.NewCard("", "", content) }
func surface(col color.Color, content fyne.CanvasObject) fyne.CanvasObject {
	return container.NewStack(canvas.NewRectangle(col), content)
}
func spacerH(h float32) fyne.CanvasObject {
	r := canvas.NewRectangle(color.Transparent)
	r.SetMinSize(fyne.NewSize(1, h))
	return r
}
func text(s string, size float32, bold bool, col color.Color) *canvas.Text {
	t := canvas.NewText(s, col)
	t.TextSize = size
	t.TextStyle = fyne.TextStyle{Bold: bold}
	return t
}
func wrapped(s string, size float32, col color.Color) fyne.CanvasObject {
	l := widget.NewLabel(s)
	l.Wrapping = fyne.TextWrapWord
	l.TextStyle = fyne.TextStyle{}
	return container.NewStack(l)
}
func secondaryButton(s string) fyne.CanvasObject { b := widget.NewButton(s, func() {}); return b }
func primaryButton(s string) *widget.Button {
	b := widget.NewButton(s, func() {})
	b.Importance = widget.HighImportance
	return b
}
func statusChip(s string) fyne.CanvasObject {
	return surface(tealSoft, container.NewPadded(text(s, 9, true, ink)))
}
