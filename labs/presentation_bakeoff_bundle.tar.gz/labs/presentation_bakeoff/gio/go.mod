module github.com/ECO-evidence-casework-one/eco/labs/presentation_bakeoff/gio

go 1.24.0

require (
	gioui.org v0.10.1
	github.com/ECO-evidence-casework-one/eco v0.0.0
)

replace github.com/ECO-evidence-casework-one/eco => ../../..
