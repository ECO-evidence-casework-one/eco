package main

import (
	"fmt"
	"image"
	"image/png"
	"os"
	"path/filepath"

	renderer "github.com/ECO-evidence-casework-one/eco/labs/presentation_bakeoff/gio/render"
	"github.com/ECO-evidence-casework-one/eco/labs/presentation_bakeoff/shared"
)

func main() {
	fixture := filepath.Join("..", "fixture", "p2_snapshot.json")
	out := "out"
	if len(os.Args) > 1 {
		fixture = os.Args[1]
	}
	if len(os.Args) > 2 {
		out = os.Args[2]
	}
	s, err := shared.Load(fixture)
	if err != nil {
		panic(err)
	}
	if err := os.MkdirAll(out, 0755); err != nil {
		panic(err)
	}
	r := renderer.New()
	for _, screen := range []string{"workspace", "ask-eco"} {
		img, err := r.Render(s, screen, 1280, 800)
		if err != nil {
			panic(err)
		}
		path := filepath.Join(out, screen+"_1280x800.png")
		f, err := os.Create(path)
		if err != nil {
			panic(err)
		}
		if err := png.Encode(f, img); err != nil {
			_ = f.Close()
			panic(err)
		}
		if err := f.Close(); err != nil {
			panic(err)
		}
		info, _ := os.Stat(path)
		mean, min, max := imageStats(img)
		fmt.Printf("RENDER %s %d bytes VISUAL_METRIC mean=%d,%d,%d min=%d,%d,%d max=%d,%d,%d\n", path, info.Size(), mean[0], mean[1], mean[2], min[0], min[1], min[2], max[0], max[1], max[2])
	}
}

func imageStats(img image.Image) (mean, min, max [3]uint64) {
	min = [3]uint64{255, 255, 255}
	b := img.Bounds()
	var n uint64
	for y := b.Min.Y; y < b.Max.Y; y++ {
		for x := b.Min.X; x < b.Max.X; x++ {
			r, g, bb, _ := img.At(x, y).RGBA()
			vals := [3]uint64{uint64(r >> 8), uint64(g >> 8), uint64(bb >> 8)}
			for i, v := range vals {
				mean[i] += v
				if v < min[i] {
					min[i] = v
				}
				if v > max[i] {
					max[i] = v
				}
			}
			n++
		}
	}
	if n > 0 {
		for i := range mean {
			mean[i] /= n
		}
	}
	return
}
