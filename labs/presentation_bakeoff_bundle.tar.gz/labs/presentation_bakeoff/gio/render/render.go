package render

import (
	"fmt"
	"image"
	"image/color"
	"strings"
	"time"

	"gioui.org/font"
	"gioui.org/font/gofont"
	"gioui.org/gpu/headless"
	"gioui.org/layout"
	"gioui.org/op"
	"gioui.org/op/clip"
	"gioui.org/op/paint"
	"gioui.org/text"
	"gioui.org/unit"
	"gioui.org/widget/material"

	"github.com/ECO-evidence-casework-one/eco/labs/presentation_bakeoff/shared"
)

var (
	bg        = color.NRGBA{R: 246, G: 249, B: 248, A: 255}
	panel     = color.NRGBA{R: 255, G: 255, B: 255, A: 255}
	ink       = color.NRGBA{R: 9, G: 48, B: 55, A: 255}
	muted     = color.NRGBA{R: 86, G: 110, B: 114, A: 255}
	line      = color.NRGBA{R: 214, G: 226, B: 224, A: 255}
	nav       = color.NRGBA{R: 0, G: 77, B: 78, A: 255}
	nav2      = color.NRGBA{R: 1, G: 101, B: 98, A: 255}
	teal      = color.NRGBA{R: 0, G: 133, B: 124, A: 255}
	tealSoft  = color.NRGBA{R: 231, G: 247, B: 244, A: 255}
	blueSoft  = color.NRGBA{R: 235, G: 244, B: 255, A: 255}
	amberSoft = color.NRGBA{R: 255, G: 246, B: 229, A: 255}
	greenSoft = color.NRGBA{R: 234, G: 247, B: 237, A: 255}
)

type Renderer struct {
	th *material.Theme
}

func New() *Renderer {
	th := material.NewTheme()
	th.Shaper = text.NewShaper(text.WithCollection(gofont.Collection()))
	th.TextSize = 14
	th.Fg = ink
	th.Bg = bg
	th.ContrastBg = teal
	th.ContrastFg = color.NRGBA{R: 255, G: 255, B: 255, A: 255}
	th.FingerSize = 44
	return &Renderer{th: th}
}

func (r *Renderer) Render(snapshot shared.Snapshot, screen string, width, height int) (*image.RGBA, error) {
	var ops op.Ops
	gtx := layout.Context{
		Ops:         &ops,
		Now:         time.Date(2026, 8, 8, 15, 30, 0, 0, time.UTC),
		Metric:      unit.Metric{PxPerDp: 1, PxPerSp: 1},
		Constraints: layout.Exact(image.Pt(width, height)),
	}
	paint.FillShape(gtx.Ops, bg, clip.Rect(image.Rect(0, 0, width, height)).Op())
	r.shell(gtx, snapshot, screen)

	w, err := headless.NewWindow(width, height)
	if err != nil {
		return nil, fmt.Errorf("headless window: %w", err)
	}
	defer w.Release()
	if err := w.Frame(&ops); err != nil {
		return nil, fmt.Errorf("frame: %w", err)
	}
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	if err := w.Screenshot(img); err != nil {
		return nil, fmt.Errorf("screenshot: %w", err)
	}
	return img, nil
}

func (r *Renderer) shell(gtx layout.Context, s shared.Snapshot, screen string) layout.Dimensions {
	return layout.Flex{Axis: layout.Horizontal}.Layout(gtx,
		layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.sidebar(gtx, s.Navigation, screen) }),
		layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
			return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
				layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.topbar(gtx, s, screen) }),
				layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
					gtx.Constraints.Min = image.Point{}
					if screen == "ask-eco" {
						return r.askECO(gtx, s.AskECO)
					}
					return r.workspace(gtx, s.Workspace)
				}),
				layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.statusbar(gtx) }),
			)
		}),
	)
}

func (r *Renderer) sidebar(gtx layout.Context, navItems []shared.NavItem, active string) layout.Dimensions {
	w := 190
	gtx.Constraints.Min.X, gtx.Constraints.Max.X = w, w
	paint.FillShape(gtx.Ops, nav, clip.Rect(image.Rect(0, 0, w, gtx.Constraints.Max.Y)).Op())
	return layout.Inset{Top: 22, Right: 14, Bottom: 16, Left: 14}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Axis: layout.Vertical}.Layout(gtx,
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return r.column(gtx, 2,
					func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, "ECO", 26, color.NRGBA{255, 255, 255, 255}, font.Bold, 1)
					},
					func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, "Evidence & Casework One", 13, color.NRGBA{230, 247, 245, 255}, font.Medium, 1)
					},
					func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, "Private · Offline", 11, color.NRGBA{173, 218, 214, 255}, font.Normal, 1)
					},
				)
			}),
			layout.Rigid(r.spacer(22)),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return r.label(gtx, "MATTER", 10, color.NRGBA{140, 199, 195, 255}, font.Medium, 1)
			}),
			layout.Rigid(r.spacer(8)),
			layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
				children := make([]layout.FlexChild, 0, len(navItems))
				for _, item := range navItems {
					it := item
					children = append(children, layout.Rigid(func(gtx layout.Context) layout.Dimensions {
						isActive := (active == "workspace" && it.ID == "workspace") || (active == "ask-eco" && it.ID == "ask-eco")
						return r.navItem(gtx, it, isActive)
					}))
				}
				return layout.Flex{Axis: layout.Vertical}.Layout(gtx, children...)
			}),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return r.card(gtx, nav2, 10, 12, func(gtx layout.Context) layout.Dimensions {
					return r.column(gtx, 4,
						func(gtx layout.Context) layout.Dimensions {
							return r.label(gtx, "Casework Core ready", 12, color.NRGBA{255, 255, 255, 255}, font.Medium, 1)
						},
						func(gtx layout.Context) layout.Dimensions {
							return r.label(gtx, "4 evidence · 7 findings", 10, color.NRGBA{198, 231, 228, 255}, font.Normal, 1)
						},
						func(gtx layout.Context) layout.Dimensions {
							return r.label(gtx, "Development Sentinel active", 10, color.NRGBA{198, 231, 228, 255}, font.Normal, 1)
						},
					)
				})
			}),
		)
	})
}

func (r *Renderer) navItem(gtx layout.Context, item shared.NavItem, active bool) layout.Dimensions {
	h := 35
	gtx.Constraints.Min.Y, gtx.Constraints.Max.Y = h, h
	if active {
		paint.FillShape(gtx.Ops, color.NRGBA{R: 5, G: 137, B: 128, A: 255}, clip.UniformRRect(image.Rect(0, 0, gtx.Constraints.Max.X, h), 7).Op(gtx.Ops))
	}
	return layout.Inset{Left: 10, Right: 8}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Alignment: layout.Middle}.Layout(gtx,
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return r.label(gtx, navGlyph(item.ID), 13, color.NRGBA{220, 244, 242, 255}, font.Medium, 1)
			}),
			layout.Rigid(r.hspacer(9)),
			layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
				return r.label(gtx, item.Label, 12, color.NRGBA{244, 252, 251, 255}, font.Medium, 1)
			}),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				if item.Count == 0 {
					return layout.Dimensions{}
				}
				return r.pill(gtx, fmt.Sprint(item.Count), color.NRGBA{R: 13, G: 151, B: 141, A: 255}, color.NRGBA{255, 255, 255, 255})
			}),
		)
	})
}

func navGlyph(id string) string {
	switch id {
	case "workspace":
		return "⌂"
	case "evidence":
		return "▤"
	case "findings":
		return "✓"
	case "timeline":
		return "◷"
	case "people":
		return "◎"
	case "issues":
		return "◇"
	case "work":
		return "☑"
	case "current-position":
		return "▥"
	case "reports":
		return "▧"
	case "ask-eco":
		return "◉"
	case "activity":
		return "↻"
	case "tools":
		return "•••"
	default:
		return "⚙"
	}
}

func (r *Renderer) topbar(gtx layout.Context, s shared.Snapshot, screen string) layout.Dimensions {
	h := 68
	gtx.Constraints.Min.Y, gtx.Constraints.Max.Y = h, h
	paint.FillShape(gtx.Ops, panel, clip.Rect(image.Rect(0, 0, gtx.Constraints.Max.X, h)).Op())
	paint.FillShape(gtx.Ops, line, clip.Rect(image.Rect(0, h-1, gtx.Constraints.Max.X, h)).Op())
	return layout.Inset{Top: 12, Right: 18, Bottom: 12, Left: 18}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Alignment: layout.Middle}.Layout(gtx,
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, "General Casework 1 ▾", 190) }),
			layout.Rigid(r.hspacer(14)),
			layout.Flexed(1, func(gtx layout.Context) layout.Dimensions { return r.searchBox(gtx) }),
			layout.Rigid(r.hspacer(14)),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return r.outlineButton(gtx, fmt.Sprintf("%d findings", s.Navigation[2].Count), 96)
			}),
			layout.Rigid(r.hspacer(10)),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.primaryButton(gtx, "Ask ECO", 90) }),
		)
	})
}

func (r *Renderer) workspace(gtx layout.Context, m shared.WorkspaceModel) layout.Dimensions {
	return layout.Inset{Top: 20, Right: 22, Bottom: 16, Left: 22}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		return r.column(gtx, 12,
			func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Alignment: layout.Middle}.Layout(gtx,
					layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
						return r.headingBlock(gtx, "Matter Workspace", "At-a-glance overview with key actions and updates.")
					}),
					layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, "What's new", 104) }),
					layout.Rigid(r.hspacer(8)),
					layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, "Explain", 84) }),
				)
			},
			func(gtx layout.Context) layout.Dimensions { return r.matterHeader(gtx, m) },
			func(gtx layout.Context) layout.Dimensions { return r.metricRow(gtx, m.Metrics) },
			func(gtx layout.Context) layout.Dimensions { return r.journey(gtx, m.Journey) },
			func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Axis: layout.Horizontal}.Layout(gtx,
					layout.Flexed(.65, func(gtx layout.Context) layout.Dimensions { return r.threadsPanel(gtx, m.Threads) }),
					layout.Rigid(r.hspacer(12)),
					layout.Flexed(.35, func(gtx layout.Context) layout.Dimensions { return r.insightPanel(gtx, m) }),
				)
			},
			func(gtx layout.Context) layout.Dimensions { return r.quickActions(gtx, m.QuickActions) },
		)
	})
}

func (r *Renderer) headingBlock(gtx layout.Context, title, sub string) layout.Dimensions {
	return r.column(gtx, 2,
		func(gtx layout.Context) layout.Dimensions { return r.label(gtx, title, 23, ink, font.Bold, 1) },
		func(gtx layout.Context) layout.Dimensions { return r.label(gtx, sub, 12, muted, font.Normal, 1) },
	)
}

func (r *Renderer) matterHeader(gtx layout.Context, m shared.WorkspaceModel) layout.Dimensions {
	return r.card(gtx, panel, 10, 14, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Alignment: layout.Middle}.Layout(gtx,
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return r.circleBadge(gtx, "M", 44)
			}),
			layout.Rigid(r.hspacer(12)),
			layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
				return r.column(gtx, 2,
					func(gtx layout.Context) layout.Dimensions { return r.label(gtx, m.Title, 17, ink, font.Bold, 1) },
					func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, m.Subtitle+" · "+m.Context, 11, muted, font.Normal, 1)
					},
				)
			}),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, "Edit Matter", 90) }),
		)
	})
}

func (r *Renderer) metricRow(gtx layout.Context, metrics []shared.Metric) layout.Dimensions {
	children := make([]layout.FlexChild, 0, len(metrics)*2)
	for i, metric := range metrics {
		m := metric
		if i > 0 {
			children = append(children, layout.Rigid(r.hspacer(10)))
		}
		children = append(children, layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
			col := blueSoft
			switch m.Tone {
			case "review":
				col = color.NRGBA{R: 244, G: 238, B: 255, A: 255}
			case "warning":
				col = amberSoft
			case "success":
				col = greenSoft
			}
			return r.card(gtx, col, 9, 12, func(gtx layout.Context) layout.Dimensions {
				return r.column(gtx, 2,
					func(gtx layout.Context) layout.Dimensions { return r.label(gtx, m.Value, 24, ink, font.Bold, 1) },
					func(gtx layout.Context) layout.Dimensions { return r.label(gtx, m.Label, 12, ink, font.Medium, 1) },
					func(gtx layout.Context) layout.Dimensions { return r.label(gtx, m.Detail, 10, muted, font.Normal, 1) },
				)
			})
		}))
	}
	return layout.Flex{Axis: layout.Horizontal}.Layout(gtx, children...)
}

func (r *Renderer) journey(gtx layout.Context, steps []shared.JourneyStep) layout.Dimensions {
	return r.card(gtx, panel, 10, 12, func(gtx layout.Context) layout.Dimensions {
		return r.column(gtx, 8,
			func(gtx layout.Context) layout.Dimensions { return r.label(gtx, "Case journey", 12, ink, font.Bold, 1) },
			func(gtx layout.Context) layout.Dimensions {
				children := make([]layout.FlexChild, 0, len(steps)*2)
				for i, step := range steps {
					st := step
					if i > 0 {
						children = append(children, layout.Rigid(r.hspacer(8)))
					}
					children = append(children, layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
						return r.column(gtx, 2,
							func(gtx layout.Context) layout.Dimensions {
								return r.pill(gtx, fmt.Sprintf("%d  %s", st.Number, st.Label), func() color.NRGBA {
									if st.Active {
										return tealSoft
									}
									return bg
								}(), ink)
							},
							func(gtx layout.Context) layout.Dimensions { return r.label(gtx, st.Detail, 9, muted, font.Normal, 1) },
						)
					}))
				}
				return layout.Flex{Axis: layout.Horizontal}.Layout(gtx, children...)
			},
		)
	})
}

func (r *Renderer) threadsPanel(gtx layout.Context, threads []shared.ThreadSummary) layout.Dimensions {
	return r.card(gtx, panel, 10, 12, func(gtx layout.Context) layout.Dimensions {
		parts := []layout.Widget{func(gtx layout.Context) layout.Dimensions {
			return r.label(gtx, "Key case threads", 12, ink, font.Bold, 1)
		}}
		limit := 3
		if len(threads) < limit {
			limit = len(threads)
		}
		for i := 0; i < limit; i++ {
			th := threads[i]
			parts = append(parts, func(gtx layout.Context) layout.Dimensions {
				return r.card(gtx, bg, 7, 9, func(gtx layout.Context) layout.Dimensions {
					return r.column(gtx, 2,
						func(gtx layout.Context) layout.Dimensions {
							return layout.Flex{Alignment: layout.Middle}.Layout(gtx, layout.Flexed(1, func(gtx layout.Context) layout.Dimensions { return r.label(gtx, th.Title, 11, ink, font.Medium, 1) }), layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.pill(gtx, th.Status, amberSoft, ink) }))
						},
						func(gtx layout.Context) layout.Dimensions {
							return r.label(gtx, fmt.Sprintf("%d source(s) · %d issue · %d missing · %d task · %d comm", th.EvidenceCount, th.IssueCount, th.MissingCount, th.TaskCount, th.CommunicationCount), 9, muted, font.Normal, 1)
						},
						func(gtx layout.Context) layout.Dimensions {
							return r.label(gtx, th.EvidenceExcerpt, 9, muted, font.Normal, 2)
						},
					)
				})
			})
		}
		return r.column(gtx, 7, parts...)
	})
}

func (r *Renderer) insightPanel(gtx layout.Context, m shared.WorkspaceModel) layout.Dimensions {
	return r.column(gtx, 10,
		func(gtx layout.Context) layout.Dimensions {
			return r.card(gtx, panel, 10, 11, func(gtx layout.Context) layout.Dimensions {
				parts := []layout.Widget{func(gtx layout.Context) layout.Dimensions {
					return r.label(gtx, "What ECO found", 12, ink, font.Bold, 1)
				}}
				for _, s := range m.FindingsSummary {
					text := s
					parts = append(parts, func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, "•  "+text, 9, muted, font.Normal, 2)
					})
				}
				return r.column(gtx, 5, parts...)
			})
		},
		func(gtx layout.Context) layout.Dimensions {
			return r.card(gtx, tealSoft, 10, 11, func(gtx layout.Context) layout.Dimensions {
				return r.column(gtx, 4,
					func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, "Recommended next action", 11, ink, font.Bold, 1)
					},
					func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, m.NextActionTitle, 10, ink, font.Medium, 2)
					},
					func(gtx layout.Context) layout.Dimensions {
						return r.label(gtx, m.NextActionDetail, 9, muted, font.Normal, 3)
					},
					func(gtx layout.Context) layout.Dimensions { return r.primaryButton(gtx, "Open case thread", 118) },
				)
			})
		},
	)
}

func (r *Renderer) quickActions(gtx layout.Context, actions []shared.Action) layout.Dimensions {
	children := make([]layout.FlexChild, 0, len(actions)*2)
	for i, a := range actions {
		action := a
		if i > 0 {
			children = append(children, layout.Rigid(r.hspacer(7)))
		}
		children = append(children, layout.Flexed(1, func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, action.Label, 0) }))
	}
	return layout.Flex{Axis: layout.Horizontal}.Layout(gtx, children...)
}

func (r *Renderer) askECO(gtx layout.Context, m shared.AskECOModel) layout.Dimensions {
	return layout.Inset{Top: 20, Right: 22, Bottom: 16, Left: 22}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		return r.column(gtx, 12,
			func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Alignment: layout.Middle}.Layout(gtx,
					layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
						return r.headingBlock(gtx, "Ask ECO", "Private local casework conversation. Answers stay linked to this Matter and its sources.")
					}),
					layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, "New conversation", 122) }),
					layout.Rigid(r.hspacer(8)),
					layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, "Export conversation", 132) }),
				)
			},
			func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Axis: layout.Horizontal}.Layout(gtx,
					layout.Flexed(.22, func(gtx layout.Context) layout.Dimensions { return r.conversationPane(gtx, m) }),
					layout.Rigid(r.hspacer(12)),
					layout.Flexed(.56, func(gtx layout.Context) layout.Dimensions { return r.messagePane(gtx, m) }),
					layout.Rigid(r.hspacer(12)),
					layout.Flexed(.22, func(gtx layout.Context) layout.Dimensions { return r.askActionsPane(gtx, m) }),
				)
			},
		)
	})
}

func (r *Renderer) conversationPane(gtx layout.Context, m shared.AskECOModel) layout.Dimensions {
	return r.card(gtx, panel, 10, 12, func(gtx layout.Context) layout.Dimensions {
		parts := []layout.Widget{func(gtx layout.Context) layout.Dimensions {
			return r.label(gtx, "Conversations", 12, ink, font.Bold, 1)
		}}
		for _, c := range m.Conversations {
			cc := c
			parts = append(parts, func(gtx layout.Context) layout.Dimensions {
				col := bg
				if cc.Active {
					col = tealSoft
				}
				return r.card(gtx, col, 7, 9, func(gtx layout.Context) layout.Dimensions {
					return r.column(gtx, 2, func(gtx layout.Context) layout.Dimensions { return r.label(gtx, cc.Title, 10, ink, font.Medium, 1) }, func(gtx layout.Context) layout.Dimensions { return r.label(gtx, cc.Updated, 9, muted, font.Normal, 1) })
				})
			})
		}
		return r.column(gtx, 8, parts...)
	})
}

func (r *Renderer) messagePane(gtx layout.Context, m shared.AskECOModel) layout.Dimensions {
	return r.card(gtx, panel, 10, 12, func(gtx layout.Context) layout.Dimensions {
		return r.column(gtx, 9,
			func(gtx layout.Context) layout.Dimensions {
				return layout.Flex{Alignment: layout.Middle}.Layout(gtx, layout.Flexed(1, func(gtx layout.Context) layout.Dimensions { return r.label(gtx, m.MatterTitle, 11, ink, font.Bold, 1) }), layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.pill(gtx, m.StatusBadge, greenSoft, ink) }))
			},
			func(gtx layout.Context) layout.Dimensions {
				return r.label(gtx, m.ScopeSummary, 9, muted, font.Normal, 1)
			},
			func(gtx layout.Context) layout.Dimensions {
				return r.card(gtx, bg, 8, 12, func(gtx layout.Context) layout.Dimensions {
					parts := make([]layout.Widget, 0, len(m.Messages))
					for _, msg := range m.Messages {
						mm := msg
						parts = append(parts, func(gtx layout.Context) layout.Dimensions {
							isUser := mm.Role == "user"
							col := panel
							if isUser {
								col = tealSoft
							}
							return r.card(gtx, col, 8, 10, func(gtx layout.Context) layout.Dimensions {
								who := "ECO"
								if isUser {
									who = "You"
								}
								return r.column(gtx, 4,
									func(gtx layout.Context) layout.Dimensions {
										return r.label(gtx, who+"   "+mm.At, 9, muted, font.Medium, 1)
									},
									func(gtx layout.Context) layout.Dimensions { return r.label(gtx, mm.Text, 11, ink, font.Normal, 5) },
									func(gtx layout.Context) layout.Dimensions {
										if len(mm.Sources) == 0 {
											return layout.Dimensions{}
										}
										names := make([]string, 0, len(mm.Sources))
										for _, s := range mm.Sources {
											names = append(names, s.Label)
										}
										return r.label(gtx, "Sources: "+strings.Join(names, " · "), 9, teal, font.Medium, 2)
									},
								)
							})
						})
					}
					if len(parts) == 0 {
						parts = append(parts, func(gtx layout.Context) layout.Dimensions {
							return r.label(gtx, m.EmptyState, 10, muted, font.Normal, 3)
						})
					}
					return r.column(gtx, 8, parts...)
				})
			},
			func(gtx layout.Context) layout.Dimensions { return r.composer(gtx, m.ComposerPlaceholder) },
		)
	})
}

func (r *Renderer) askActionsPane(gtx layout.Context, m shared.AskECOModel) layout.Dimensions {
	return r.card(gtx, panel, 10, 11, func(gtx layout.Context) layout.Dimensions {
		parts := []layout.Widget{func(gtx layout.Context) layout.Dimensions {
			return r.label(gtx, "Actions & questions", 12, ink, font.Bold, 1)
		}}
		for _, a := range m.SuggestedQuestions {
			aa := a
			parts = append(parts, func(gtx layout.Context) layout.Dimensions { return r.outlineButton(gtx, aa.Label, 0) })
		}
		parts = append(parts, func(gtx layout.Context) layout.Dimensions {
			return r.label(gtx, "Sources in this answer", 10, ink, font.Bold, 1)
		})
		for _, s := range m.Sources {
			ss := s
			parts = append(parts, func(gtx layout.Context) layout.Dimensions {
				return r.label(gtx, "• "+ss.Label, 9, teal, font.Medium, 2)
			})
		}
		return r.column(gtx, 7, parts...)
	})
}

func (r *Renderer) composer(gtx layout.Context, placeholder string) layout.Dimensions {
	return r.card(gtx, panel, 9, 8, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Alignment: layout.Middle}.Layout(gtx,
			layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
				return r.label(gtx, placeholder, 10, muted, font.Normal, 1)
			}),
			layout.Rigid(r.hspacer(8)),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.primaryButton(gtx, "Send", 70) }),
		)
	})
}

func (r *Renderer) statusbar(gtx layout.Context) layout.Dimensions {
	h := 28
	gtx.Constraints.Min.Y, gtx.Constraints.Max.Y = h, h
	paint.FillShape(gtx.Ops, panel, clip.Rect(image.Rect(0, 0, gtx.Constraints.Max.X, h)).Op())
	return layout.Inset{Left: 18, Right: 18}.Layout(gtx, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Alignment: layout.Middle}.Layout(gtx,
			layout.Flexed(1, func(gtx layout.Context) layout.Dimensions { return r.label(gtx, "●  Ready", 9, teal, font.Medium, 1) }),
			layout.Rigid(func(gtx layout.Context) layout.Dimensions {
				return r.label(gtx, "Auto-save: On   ·   Local only   ·   Sentinel: Active", 9, muted, font.Normal, 1)
			}),
		)
	})
}

func (r *Renderer) searchBox(gtx layout.Context) layout.Dimensions {
	return r.card(gtx, bg, 8, 10, func(gtx layout.Context) layout.Dimensions {
		return layout.Flex{Alignment: layout.Middle}.Layout(gtx, layout.Flexed(1, func(gtx layout.Context) layout.Dimensions {
			return r.label(gtx, "⌕  Search this Matter or run an action…", 10, muted, font.Normal, 1)
		}), layout.Rigid(func(gtx layout.Context) layout.Dimensions { return r.label(gtx, "Ctrl+K", 9, muted, font.Medium, 1) }))
	})
}

func (r *Renderer) outlineButton(gtx layout.Context, text string, width int) layout.Dimensions {
	if width > 0 {
		gtx.Constraints.Min.X, gtx.Constraints.Max.X = width, width
	}
	gtx.Constraints.Min.Y = 38
	return r.card(gtx, panel, 7, 8, func(gtx layout.Context) layout.Dimensions {
		l := material.Label(r.th, 10, text)
		l.Color = ink
		l.Font.Weight = font.Medium
		l.Alignment = textpkgMiddle()
		l.MaxLines = 2
		return l.Layout(gtx)
	})
}

func textpkgMiddle() text.Alignment { return text.Middle }

func (r *Renderer) primaryButton(gtx layout.Context, label string, width int) layout.Dimensions {
	if width > 0 {
		gtx.Constraints.Min.X, gtx.Constraints.Max.X = width, width
	}
	gtx.Constraints.Min.Y = 38
	return r.card(gtx, teal, 7, 8, func(gtx layout.Context) layout.Dimensions {
		l := material.Label(r.th, 10, label)
		l.Color = color.NRGBA{255, 255, 255, 255}
		l.Font.Weight = font.Medium
		l.Alignment = text.Middle
		return l.Layout(gtx)
	})
}

func (r *Renderer) circleBadge(gtx layout.Context, label string, size int) layout.Dimensions {
	gtx.Constraints.Min = image.Pt(size, size)
	gtx.Constraints.Max = image.Pt(size, size)
	paint.FillShape(gtx.Ops, tealSoft, clip.Ellipse(image.Rect(0, 0, size, size)).Op(gtx.Ops))
	return layout.Center.Layout(gtx, func(gtx layout.Context) layout.Dimensions { return r.label(gtx, label, 16, teal, font.Bold, 1) })
}

func (r *Renderer) pill(gtx layout.Context, txt string, col, fg color.NRGBA) layout.Dimensions {
	return r.card(gtx, col, 12, 5, func(gtx layout.Context) layout.Dimensions { return r.label(gtx, txt, 9, fg, font.Medium, 1) })
}

func (r *Renderer) card(gtx layout.Context, col color.NRGBA, radius, pad int, child layout.Widget) layout.Dimensions {
	macro := op.Record(gtx.Ops)
	inner := layout.Inset{Top: unit.Dp(pad), Right: unit.Dp(pad), Bottom: unit.Dp(pad), Left: unit.Dp(pad)}.Layout(gtx, child)
	call := macro.Stop()
	sz := inner.Size
	paint.FillShape(gtx.Ops, col, clip.UniformRRect(image.Rectangle{Max: sz}, radius).Op(gtx.Ops))
	if col == panel { // subtle border
		// Border is intentionally omitted from spike paint path; cards are separated by background and spacing.
	}
	call.Add(gtx.Ops)
	return inner
}

func (r *Renderer) label(gtx layout.Context, txt string, size unit.Sp, col color.NRGBA, weight font.Weight, maxLines int) layout.Dimensions {
	l := material.Label(r.th, size, txt)
	l.Color = col
	l.Font.Weight = weight
	l.MaxLines = maxLines
	l.Truncator = "…"
	return l.Layout(gtx)
}

func (r *Renderer) column(gtx layout.Context, gap int, widgets ...layout.Widget) layout.Dimensions {
	children := make([]layout.FlexChild, 0, len(widgets)*2)
	for i, w := range widgets {
		if i > 0 && gap > 0 {
			children = append(children, layout.Rigid(r.spacer(gap)))
		}
		ww := w
		children = append(children, layout.Rigid(func(gtx layout.Context) layout.Dimensions { gtx.Constraints.Min.Y = 0; return ww(gtx) }))
	}
	return layout.Flex{Axis: layout.Vertical}.Layout(gtx, children...)
}

func (r *Renderer) spacer(px int) layout.Widget {
	return func(gtx layout.Context) layout.Dimensions { return layout.Dimensions{Size: image.Pt(0, px)} }
}
func (r *Renderer) hspacer(px int) layout.Widget {
	return func(gtx layout.Context) layout.Dimensions { return layout.Dimensions{Size: image.Pt(px, 0)} }
}
