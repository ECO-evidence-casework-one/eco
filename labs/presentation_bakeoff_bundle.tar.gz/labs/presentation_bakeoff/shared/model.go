// Package shared contains only the renderer bake-off DTOs. It deliberately does
// not derive casework: labs consume the committed JSON produced by
// internal/presentationmodel from authoritative ECO state.
package shared

import (
	"encoding/json"
	"os"
)

type NavItem struct {
	ID    string `json:"id"`
	Label string `json:"label"`
	Count int    `json:"count,omitempty"`
}

type Action struct {
	ID      string `json:"id"`
	Label   string `json:"label"`
	Primary bool   `json:"primary,omitempty"`
}

type Metric struct {
	ID     string `json:"id"`
	Label  string `json:"label"`
	Value  string `json:"value"`
	Detail string `json:"detail,omitempty"`
	Tone   string `json:"tone,omitempty"`
}

type JourneyStep struct {
	ID     string `json:"id"`
	Number int    `json:"number"`
	Label  string `json:"label"`
	Detail string `json:"detail"`
	Active bool   `json:"active"`
}

type ThreadSummary struct {
	ID                 string   `json:"id"`
	Title              string   `json:"title"`
	Summary            string   `json:"summary,omitempty"`
	Status             string   `json:"status"`
	Priority           string   `json:"priority,omitempty"`
	EvidenceCount      int      `json:"evidence_count"`
	IssueCount         int      `json:"issue_count"`
	MissingCount       int      `json:"missing_count"`
	TaskCount          int      `json:"task_count"`
	CommunicationCount int      `json:"communication_count"`
	SourceNames        []string `json:"source_names,omitempty"`
	EvidenceExcerpt    string   `json:"evidence_excerpt,omitempty"`
}

type AttentionItem struct {
	ID     string `json:"id"`
	Title  string `json:"title"`
	Detail string `json:"detail,omitempty"`
	Tone   string `json:"tone,omitempty"`
	Target string `json:"target,omitempty"`
}

type WorkspaceModel struct {
	MatterID         string          `json:"matter_id"`
	Title            string          `json:"title"`
	Subtitle         string          `json:"subtitle"`
	Context          string          `json:"context,omitempty"`
	Updated          string          `json:"updated"`
	Metrics          []Metric        `json:"metrics"`
	Journey          []JourneyStep   `json:"journey"`
	Threads          []ThreadSummary `json:"threads"`
	FindingsSummary  []string        `json:"findings_summary"`
	Attention        []AttentionItem `json:"attention"`
	NextActionTitle  string          `json:"next_action_title"`
	NextActionDetail string          `json:"next_action_detail"`
	QuickActions     []Action        `json:"quick_actions"`
	HeaderActions    []Action        `json:"header_actions"`
}

type ConversationSummary struct {
	ID      string `json:"id"`
	Title   string `json:"title"`
	Updated string `json:"updated"`
	Active  bool   `json:"active"`
	Unread  bool   `json:"unread,omitempty"`
}

type SourceRef struct {
	EvidenceID string `json:"evidence_id"`
	Label      string `json:"label"`
	Quote      string `json:"quote,omitempty"`
	Page       int    `json:"page,omitempty"`
}

type Message struct {
	ID      string      `json:"id"`
	Role    string      `json:"role"`
	Text    string      `json:"text"`
	At      string      `json:"at,omitempty"`
	Sources []SourceRef `json:"sources,omitempty"`
	State   string      `json:"state,omitempty"`
}

type AskECOModel struct {
	MatterID            string                `json:"matter_id"`
	MatterTitle         string                `json:"matter_title"`
	StatusBadge         string                `json:"status_badge"`
	ScopeSummary        string                `json:"scope_summary"`
	Conversations       []ConversationSummary `json:"conversations"`
	ActiveConversation  string                `json:"active_conversation"`
	Messages            []Message             `json:"messages"`
	SuggestedQuestions  []Action              `json:"suggested_questions"`
	Sources             []SourceRef           `json:"sources"`
	ComposerPlaceholder string                `json:"composer_placeholder"`
	EmptyState          string                `json:"empty_state,omitempty"`
	HeaderActions       []Action              `json:"header_actions"`
}

type Snapshot struct {
	Navigation []NavItem      `json:"navigation"`
	Workspace  WorkspaceModel `json:"workspace"`
	AskECO     AskECOModel    `json:"ask_eco"`
}

func Load(path string) (Snapshot, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return Snapshot{}, err
	}
	var s Snapshot
	if err := json.Unmarshal(data, &s); err != nil {
		return Snapshot{}, err
	}
	return s, nil
}
