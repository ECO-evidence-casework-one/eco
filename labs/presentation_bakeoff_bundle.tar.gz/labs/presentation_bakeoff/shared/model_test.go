package shared

import (
	"path/filepath"
	"testing"
)

func TestFixtureSchemaContainsRepresentativeP2Surfaces(t *testing.T) {
	s, err := Load(filepath.Join("..", "fixture", "p2_snapshot.json"))
	if err != nil {
		t.Fatal(err)
	}
	if len(s.Navigation) != 13 || len(s.Workspace.Metrics) != 4 || len(s.Workspace.QuickActions) < 6 || len(s.AskECO.SuggestedQuestions) < 6 {
		t.Fatalf("fixture regressed to sparse representation: nav=%d metrics=%d quick=%d ask=%d", len(s.Navigation), len(s.Workspace.Metrics), len(s.Workspace.QuickActions), len(s.AskECO.SuggestedQuestions))
	}
}
